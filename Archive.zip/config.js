var config = {};
config.twitterKeys = {};
config.twitterKeys.consumer_key = '9oVh7BXbJsCYpyC98hN1vCr5j';
config.twitterKeys.consumer_secret = 'RaRCXEhMQPjhhMGhwdOZDXQhFPb3eXQDg5YT9gUuuZk8RgUOq0';
config.twitterKeys.access_token_key = '54642043-QsXx3bSjhqnmq4H0WPfvfcrmrq5hXBCCIznXgF5Bx';
config.twitterKeys.access_token_secret = 'P4ZJPwb0F1JW8DKJYfgNwixwleaJU1HmRTD9tKMEjwQJF';
module.exports = config;
